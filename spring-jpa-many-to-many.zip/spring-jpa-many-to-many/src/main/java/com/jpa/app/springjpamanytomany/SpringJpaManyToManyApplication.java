package com.jpa.app.springjpamanytomany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJpaManyToManyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaManyToManyApplication.class, args);
	}
}
