package com.jpa.app.springjpaonetoone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJpaOneToOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaOneToOneApplication.class, args);
	}
}
